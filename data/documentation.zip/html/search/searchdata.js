var indexSectionsWithContent =
{
  0: "cdru",
  1: "dr",
  2: "cdru"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Pages"
};

